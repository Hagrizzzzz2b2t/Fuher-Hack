package org.bleachhack.module.mods;

import org.bleachhack.module.Module;
import org.bleachhack.module.ModuleCategory;

public class AntiChunkBan extends Module {

	public AntiChunkBan() {
		super("AntiChunkBan", KEY_UNBOUND, ModuleCategory.EXPLOITS, "Bypasses chunks bans (and bookbans).");
	}

}
