package org.bleachhack.modules.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.util.text.ITextComponent;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.HashSet;
import java.util.Set;

@Mod.EventBusSubscriber
public class HideChat {

    private static final String TARGET_PLAYER = "Hagriz";
    private static boolean isActive = true;

    @SubscribeEvent
    public static void onChatReceived(ClientChatReceivedEvent event) {
        if (isActive && event.getMessage() != null && event.getType() == 0) {
            ITextComponent message = event.getMessage();

            // Check if the message is from the target player "Hagriz"
            if (isChatFromHagriz(message)) {
                event.setCanceled(true); // Hide the message
            }
        }
    }

    @SubscribeEvent
    public static void onClientChat(ClientChatEvent event) {
        if (isActive) {
            String message = event.getMessage();
            
            // Check if the message is directed to the target player "Hagriz"
            if (isChatToHagriz(message)) {
                event.setCanceled(true); // Hide the outgoing message
            }
        }
    }

